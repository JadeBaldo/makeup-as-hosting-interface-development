import {clamp,smooth} from './trace-field.mjs';
export const CYCLE_SECONDS=360;
export const BURST_AT=348;
// Absolute time makes pause/scrub/replay deterministic, including the weighted fall.
export function performanceCycle(time){
 const t=Math.max(0,time),pressure=smooth(t/BURST_AT),crowding=smooth((t-190)/158),empty=smooth((t-BURST_AT)/5),fall=clamp((t-353)/7);
 const impact=fall>=.76?Math.sin((fall-.76)*28)*Math.exp(-(fall-.76)*18)*.025:0;
 return {pressure,crowding,empty,fall,drop:clamp((fall/.76)**2-impact),stage:t<190?'pressurising':t<BURST_AT?'crowding':t<353?'bursting':t<360?'falling':'carcass',finished:t>=360};
}
