# Altered Images — Study 03: Filled / R

Separate graphics experiment, 11 October 2026. Based on Study 02; the integrated webcam performance, earlier studies and reference archives are preserved. No webcam, external assets, new rendering library or 3D export.

## Run and inspect

Double-click `START-STUDY.bat`, then open http://localhost:8772. Alternatively run `python -m http.server 8772` in this folder. All Three.js and font assets are bundled in `vendor/`.

Drag on the R and lift to finish a trace. Each fresh trace starts an independent blister. Replay clears and repeats the prepared path; Add trace repeats it over existing residues. Clear removes every mark. Pause and the life-cycle slider let you inspect stages. Adjust softness/wobble, reflection/gloss, internal glow and rupture timing. Timing changes apply to new marks only.

The current performance study runs one 360-second sequence. The unmarked skin has subtle wet relief. New traces reach roughly 62% local swelling within 2.2 seconds, with folded highlights and delayed wobble immediately; the remaining pressure deepens gradually throughout the cycle; after 190 seconds the whole R crowds and expands to fill the viewport, with outer and inner contour warping. At 348 seconds marks rupture and briefly release two small droplets each. By 353 seconds the inner liquid is gone and the membrane loses height, retaining broad folds and tears. It falls with accelerating descent and a damped landing, settling at the bottom by 360 seconds. The clock then stops; Replay/Clear starts a new cycle. This is a single-letter interpretation, not multiple letters colliding.

Use Pause and the 0?360 second slider to inspect the ending immediately. Drawing is available until the terminal rupture, then disabled until reset. New traces join the same cycle rather than starting another six-minute clock. The prior six-minute look is saved in `saved-versions/altered-images-study-03-six-minute-before-early-texture.zip`. The earlier short-cycle state is recoverable in `saved-versions/altered-images-study-03-before-six-minute-cycle.zip` at the workspace root.

Strokes now add pressure to one fixed-size shared field and one reusable membrane mesh. There is no trace-count or segment-count gate during buildup. The trace path is deposited directly into per-vertex pressure; lifting starts another stroke, not another mesh. Repeated strokes slightly inflate existing material and deepen folds. Pressure smoothly saturates and displacement stays bounded, preserving practical rendering cost. No historical paths or independently animated blister objects accumulate. The previous per-mark version is recoverable in `saved-versions/altered-images-study-03-before-shared-surface.zip`.

Drawing is still intentionally closed during the terminal rupture/fall, as part of the six-minute sequence. Reset clears the shared field. The timeline inspects the current accumulated field at different cycle ages; it does not reconstruct which strokes existed at an earlier time. The shared skin has one local terminal tear and two brief droplets, rather than a separate rupture per historical stroke. The weighted fall remains a controlled mesh animation, not soft-body collision physics.

## Rendering and reusable modules

- `topology.mjs`: bundled-font text extrusion, subdivision, shared front/bevel/wall vertices, silhouette checks and picking in undeformed letter coordinates.
- `trace-field.mjs`: continuous trace fields and shared additive pressure, silhouette-safe path deposition, fixed-size storage and one terminal release event.
- `deformation.mjs`: actual shared body displacement, delayed wobble, local tear, recoil and retained folded skins. Most inflation is in the letter body: up to 12 units of depth displacement, 5 units of normal-directed contour motion and 4 units of slump. Remaining local body sag is preserved after rupture. These clamps bound overlapping marks and preserve the counter on tested paths. A luminous inner volume is inset along rest normals inside the slightly transmitting outer body; it follows the same displacement without coplanar side walls. A single reusable skin uses the existing letter triangles; weights and positions update in place, and unpainted regions are discarded by its shader.
- `study.mjs`: procedural local studio reflections, lighting, small transient droplets, pointer drawing, replay, inspection and controls.
- `index.html` / `style.css`: compact responsive interface. `vendor/` contains the existing rendering assets.

The 01.5 archive informed shared-body distortion only; its screen-overlap interaction was not copied. This is a controlled geometry/shader approximation rather than a pressure or fluid simulation. The letter counter and gaps stay open on the checked paths, but extreme dense overlapping traces still warrant visual scrutiny. Finite tessellation can make highlights angular. Repeated traces merge into the same folds instead of producing stacked skin meshes. Finite tessellation and strong late-stage distortion can still produce angular highlights. The unmarked blue container reads more opaque than literal transparent liquid in the current lighting; glow, wetness and folded aftermath remain art-direction questions.

## Verification

Run `node cycle.test.mjs` for the existing deformation tests plus 1,000 accepted traces, constant mesh/buffer sizes, additive pressure, counter continuity, slow pressure, terminal rupture, actual height loss, hidden liquid core, no repeat rupture, reset and the deterministic six-minute landing. Run `node browser-check.mjs` with a Chrome debugging endpoint at localhost:9230 and this study served on 8772. Browser stage captures and measurements are in `verification/`. Updated tests passed, with no browser runtime/shader errors; observed observed about 30 fps during late buildup and 60 fps settled in this browser. The browser accepted 503 strokes with one field and the same membrane mesh and triangle count; measurements are recorded in `verification/browser-results.json`.

The browser checks use timeline scrubbing and a short natural run across the rupture threshold, not a complete six-minute wall-clock rehearsal. They cover screen-filling scale, finite collapsed geometry, liquid removal, brief release, reset/replay, stopped clock and mobile viewport. The final form is a folded, flattened R across the lower screen. Jade still needs to judge its fleshiness, weight and material quality, and rehearse the full six minutes on the intended GPU/display. Multiple letters squishing together are not implemented in this single-R study.

`performance-cycle.mjs` controls global pressure, crowding, emptying and fall. The deformation module can still run its short per-mark lifecycle for focused tests, while the browser selects the six-minute performance mode. `protected-source-hashes.json` records prior studies, integrated source and saved archives for preservation checks.
